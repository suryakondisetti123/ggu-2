const fs = require('fs');
const admin = require('firebase-admin');

// Initialize Firebase Admin SDK
const serviceAccount = require('./serviceAccountKey.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
  databaseURL: "https://gguexam-10815-default-rtdb.firebaseio.com"
});

const db = admin.database();

async function uploadCodingQuestions() {
  try {
    // Read the JSON file
    const rawData = fs.readFileSync('../part-b-coding-questions.json', 'utf8');
    const questions = JSON.parse(rawData);
    
    console.log('Uploading coding questions to Firebase...');
    
    // Upload to Firebase
    await db.ref('exam_data/questions/coding').set(questions.coding);
    
    console.log('✅ Successfully uploaded coding questions to Firebase!');
    console.log(`Uploaded ${questions.coding.length} coding questions`);
    
    // Verify upload
    const snapshot = await db.ref('exam_data/questions/coding').once('value');
    const uploadedData = snapshot.val();
    console.log('Verification - Uploaded data keys:', Object.keys(uploadedData || {}));
    
  } catch (error) {
    console.error('❌ Error uploading coding questions:', error);
  } finally {
    process.exit(0);
  }
}

uploadCodingQuestions();