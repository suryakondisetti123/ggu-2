# Exam Portal API Documentation

## Base URL
```
http://localhost:3000
```

## Endpoints

### 🔧 Health Check
**GET** `/api/health`
- Check if the API server is running
- Returns server status and timestamp

### 📚 Get Questions

**GET** `/api/questions`
- Retrieve all question types (aptitude, verbal, technical, descriptive)
- Returns complete question dataset

**GET** `/api/questions/:type`
- Retrieve specific question type
- Path parameters: `aptitude`, `verbal`, `technical`, `descriptive`
- Returns questions of specified type with count

### 📤 Upload Questions

**POST** `/api/questions/upload`
- Upload complete question set (all types)
- Requires JSON body with question structure
- Validates data structure before upload

**POST** `/api/questions/descriptive`
- Upload descriptive questions only
- Requires array of descriptive question objects
- Validates array structure

## Request/Response Examples

### Get All Questions
```bash
curl -X GET http://localhost:3000/api/questions
```

### Upload Descriptive Questions
```bash
curl -X POST http://localhost:3000/api/questions/descriptive \
  -H "Content-Type: application/json" \
  -d '[
    {
      "id": "desc_1",
      "title": "CSS Specificity Question",
      "problem": "Question description",
      "marks": 10,
      "parts": {
        "a": "Part A content",
        "b": "Part B content"
      }
    }
  ]'
```

## Using with Postman

1. Import the `Exam-Portal-API.postman_collection.json` file
2. Set the `base_url` variable to your server URL
3. Use the pre-configured requests to:
   - Check API health
   - Retrieve existing questions
   - Upload new questions

## Data Structure

### Descriptive Question Format
```json
{
  "id": "unique_identifier",
  "title": "Question Title",
  "problem": "Question description",
  "marks": 10,
  "parts": {
    "a": "Part A content",
    "b": "Part B content"
  }
}
```

### Complete Question Set Format
```json
{
  "aptitude": [...],
  "verbal": [...],
  "technical": [...],
  "descriptive": [...]
}
```

## Error Handling

All endpoints return structured error responses:
```json
{
  "success": false,
  "error": "Error message"
}
```

Success responses:
```json
{
  "success": true,
  "message": "Operation completed",
  "data": {...}
}
```