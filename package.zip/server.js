const express = require('express');
const admin = require('firebase-admin');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Initialize Firebase Admin SDK
try {
  const serviceAccount = require('./serviceAccountKey.json');
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    databaseURL: "https://glacier-exam-portal-default-rtdb.firebaseio.com"
  });
  console.log('Firebase Admin SDK initialized successfully');
} catch (error) {
  console.error('Failed to initialize Firebase Admin SDK:', error.message);
  process.exit(1);
}

const db = admin.database();

// Routes

// GET all questions
app.get('/api/questions', async (req, res) => {
  try {
    const snapshot = await db.ref('exam_data/questions').once('value');
    const questions = snapshot.val();
    res.json({
      success: true,
      data: questions || {}
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// POST upload questions
app.post('/api/questions/upload', async (req, res) => {
  try {
    const questionsData = req.body;
    
    // Validate required structure
    if (!questionsData.descriptive && !questionsData.aptitude && !questionsData.verbal && !questionsData.technical) {
      return res.status(400).json({
        success: false,
        error: 'Invalid data structure. Must include at least one question type.'
      });
    }
    
    // Upload to Firebase
    const ref = db.ref('exam_data/questions');
    await ref.set(questionsData);
    
    res.json({
      success: true,
      message: 'Questions uploaded successfully',
      data: questionsData
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// POST upload descriptive questions only
app.post('/api/questions/descriptive', async (req, res) => {
  try {
    const descriptiveQuestions = req.body;
    
    // Validate array structure
    if (!Array.isArray(descriptiveQuestions)) {
      return res.status(400).json({
        success: false,
        error: 'Descriptive questions must be an array'
      });
    }
    
    // Upload to Firebase
    const ref = db.ref('exam_data/questions/descriptive');
    await ref.set(descriptiveQuestions);
    
    res.json({
      success: true,
      message: `Successfully uploaded ${descriptiveQuestions.length} descriptive questions`,
      count: descriptiveQuestions.length
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// GET specific question type
app.get('/api/questions/:type', async (req, res) => {
  try {
    const { type } = req.params;
    const validTypes = ['aptitude', 'verbal', 'technical', 'descriptive'];
    
    if (!validTypes.includes(type)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid question type. Valid types: aptitude, verbal, technical, descriptive'
      });
    }
    
    const snapshot = await db.ref(`exam_data/questions/${type}`).once('value');
    const questions = snapshot.val();
    
    res.json({
      success: true,
      type: type,
      data: questions || [],
      count: questions ? (Array.isArray(questions) ? questions.length : Object.keys(questions).length) : 0
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      error: error.message
    });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    success: true,
    message: 'Exam Portal API is running',
    timestamp: new Date().toISOString()
  });
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Exam Portal API Server running on port ${PORT}`);
  console.log(`📚 API Documentation:`);
  console.log(`   GET  /api/health`);
  console.log(`   GET  /api/questions`);
  console.log(`   GET  /api/questions/:type`);
  console.log(`   POST /api/questions/upload`);
  console.log(`   POST /api/questions/descriptive`);
});

module.exports = app;