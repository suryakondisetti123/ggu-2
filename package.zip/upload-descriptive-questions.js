const admin = require('firebase-admin');
const fs = require('fs');
const path = require('path');

// Initialize Firebase Admin SDK
try {
  const serviceAccount = require('./serviceAccountKey.json');
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    databaseURL: "https://glacier-exam-portal-default-rtdb.firebaseio.com"
  });
  console.log('Firebase Admin SDK initialized successfully');
} catch (error) {
  console.error('Failed to initialize Firebase Admin SDK:', error.message);
  process.exit(1);
}

const db = admin.database();

async function uploadDescriptiveQuestions() {
  try {
    // Read the descriptive questions JSON file
    const filePath = path.join(__dirname, '..', 'descriptive-questions.json');
    const rawData = fs.readFileSync(filePath, 'utf8');
    const questionsData = JSON.parse(rawData);
    
    console.log('Loaded descriptive questions data:', questionsData);
    
    // Upload to Firebase Realtime Database
    const ref = db.ref('exam_data/questions');
    await ref.set(questionsData);
    
    console.log('✅ Descriptive questions uploaded successfully!');
    
    // Verify the upload
    const snapshot = await ref.once('value');
    const uploadedData = snapshot.val();
    console.log('Uploaded data structure:', Object.keys(uploadedData));
    
    if (uploadedData.descriptive && uploadedData.descriptive.length > 0) {
      console.log(`✅ Successfully uploaded ${uploadedData.descriptive.length} descriptive questions`);
      console.log('Sample question:', uploadedData.descriptive[0].title);
    } else {
      console.log('❌ Upload verification failed - no descriptive questions found');
    }
    
  } catch (error) {
    console.error('❌ Error uploading descriptive questions:', error);
    process.exit(1);
  }
}

// Run the upload
uploadDescriptiveQuestions();